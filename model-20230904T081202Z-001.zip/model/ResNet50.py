import torch.nn.functional as F
import torch.nn as nn
import torch
import os
from transformers import ResNetForImageClassification


class ResNet_50(nn.Module):
    def __init__(self, device, freeze=True):
        super(ResNet_50, self).__init__()

        # Load the pre-trained Vision Transformer model
        # self.processor = ViTImageProcessor.from_pretrained('google/vit-large-patch16-224-in21k')
        self.model = ResNetForImageClassification.from_pretrained("microsoft/resnet-50")
        self.model.to(device)

        # Freeze the pre-trained layers
        for param in self.model.parameters():
            param.requires_grad = not freeze

        # Replace the last layer for fine-tuning
        num_classes = 4
        # for name, module in self.model.named_children():
        #     print(name, module)

        self.dropout = nn.Dropout(0.1)

        
        self.model.classifier[1] = nn.Linear(self.model.classifier[1].in_features, num_classes).to(device)

        # Explicitly set the parameters of the new layer to be trainable
        for param in self.model.classifier[1].parameters():
            param.requires_grad = True

    def forward(self, device, x):
        outputs = self.model(x, output_hidden_states=True)
        # Get the embeddings from the last hidden state (before the FC layer)
        # print(dir(self.model.resnet))
        ave_pool = self.model.resnet.pooler
        flatten = self.model.classifier[0]
        embeddings = flatten(ave_pool(outputs.hidden_states[-1]))
        # print("dimemsion of embedding in resnet 34: ", embeddings.shape)
        # Get the logits from the output
        logits = outputs.logits
        return embeddings, logits

    def load_model(self, path):
        self.load_state_dict(torch.load(path))

    def save_model(self, path):
        # torch.save(self.model.state_dict(), path)
        weights_path = os.path.join(path, "weights.pth")
        torch.save(self.state_dict(), weights_path)



