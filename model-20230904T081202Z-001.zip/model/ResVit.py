import torch.nn as nn
import torch
import os
import torch
import math
import torch.nn.functional as F
from util import str2bool
from transformers import ResNetForImageClassification
from transformers import ViTModel


class ResVit(nn.Module):
    def __init__(self, device, args, freeze=True, combination="18-16"):
        super(ResVit, self).__init__()
        freeze = str2bool(args.freeze)
        self.combination = combination
        # Load the pre-trained Vision Transformer model
        self.args = args

        if combination=="18-16":
          self.vit16 = ViTModel.from_pretrained('google/vit-base-patch16-224')
          self.resnet18 = ResNetForImageClassification.from_pretrained("microsoft/resnet-18")
        elif combination=="34-16":
          self.vit16 = ViTModel.from_pretrained('google/vit-base-patch16-224')
          self.resnet18 = ResNetForImageClassification.from_pretrained("microsoft/resnet-34")
        elif combination=="50-16":
          self.vit16 = ViTModel.from_pretrained('google/vit-base-patch16-224')
          self.resnet18 = ResNetForImageClassification.from_pretrained("microsoft/resnet-50")
        elif combination=="18-32":
          self.vit16 = ViTModel.from_pretrained('google/vit-base-patch32-224-in21k')
          self.resnet18 = ResNetForImageClassification.from_pretrained("microsoft/resnet-18")
        elif combination=="34-32":
          self.vit16 = ViTModel.from_pretrained('google/vit-base-patch32-224-in21k')
          self.resnet18 = ResNetForImageClassification.from_pretrained("microsoft/resnet-34")
        elif combination=="50-32":
          self.vit16 = ViTModel.from_pretrained('google/vit-base-patch32-224-in21k')
          self.resnet18 = ResNetForImageClassification.from_pretrained("microsoft/resnet-50")


        # self.resnet50 = ResNetForImageClassification.from_pretrained("microsoft/resnet-50")
        # self.resnet18 = ResNetForImageClassification.from_pretrained("microsoft/resnet-18")
        # self.vit16 = ViTModel.from_pretrained('google/vit-base-patch16-224')
        # self.vit16 = ViTModel.from_pretrained('google/vit-base-patch32-224-in21k')

        self.resnet18.to(device)
        self.vit16.to(device)

        # Freeze the pre-trained layers
        # for param in self.resnet50.parameters():
        #     param.requires_grad = not freeze
        for param in self.resnet18.parameters():
            param.requires_grad = not freeze
        for param in self.vit16.parameters():
            param.requires_grad = False
        # for param in self.vit32.parameters():
        #     param.requires_grad = False

        # Replace the last layer for fine-tuning
        num_classes = 4
        vit_feature_size = self.vit16.pooler.dense.in_features
        resnet_feature_size = self.resnet18.classifier[1].in_features
        input_size = resnet_feature_size
        self.dropout = nn.Dropout(0.2)



        # 1x1 Convolution for dimension projection
        if combination=="50-16" or combination=="50-32":
          self.vit_projection_1 = nn.Conv2d(2048, 768, kernel_size=1).to(device)
        else:
          self.vit_projection_1 = nn.Conv2d(512, 768, kernel_size=1).to(device)
          
        #
        self.attention_classifier = Classifier(device, args, 768, num_classes).to(device)
        self.concat_classifier = Classifier(device, args, 512+768, num_classes).to(device)
        self.addition_classifier = Classifier(device, args, 768, num_classes).to(device)

        # Attention
        self.query = nn.Conv2d(768, 768, kernel_size=1).to(device)
        self.key = nn.Conv2d(512, 768, kernel_size=1).to(device)
        self.value = nn.Conv2d(512, 768, kernel_size=1).to(device)

    def transpose_for_scores(self, x: torch.Tensor) -> torch.Tensor:
        # x: Bx768x7x7
        x = x.permute(0,2,3,1)  # x: Bx7x7x768
        new_x_shape = x.size()[:-1] + (12, 64)  # new_x_shape: Bx7x7x12x64
        x = x.view(new_x_shape)  # x: Bx7x7x12x64
        return x.permute(0,3,4,1,2)  # x: Bx12x64x7x7
         

    def forward(self, device, x):
        # Feature of resnet 34
        outputs_resnet18 = self.resnet18(x, output_hidden_states=True)
        # ave_pool = self.resnet18.resnet.pooler
        # flatten = self.resnet18.classifier[0]
        feature_resnet18 = outputs_resnet18.hidden_states[-1]   # Bx512x7x7

        # Feature of vit16
        outputs_vit16 = self.vit16(pixel_values=x)
        feature_vit16 = outputs_vit16.last_hidden_state[:, 1:, :]
        # reshape ResNet and ViT into the same spatial dimensions and do down-sampling to match the size
        if self.combination=="18-16" or self.combination=="34-16" or self.combination=="50-16":
          vit_features_reshaped = feature_vit16.reshape(x.shape[0], 14, 14, 768).permute(0, 3, 1, 2)  # Bx768x14x14
        elif self.combination=="18-32" or self.combination=="34-32" or self.combination=="50-32":
          vit_features_reshaped = feature_vit16.reshape(x.shape[0], 7, 7, 768).permute(0, 3, 1, 2)  # Bx768x7x7
        vit_features_down_sampled = F.interpolate(vit_features_reshaped, size=(7, 7), mode='bilinear', align_corners=False)  # Bx768x7x7

        if str2bool(self.args.attention):
            # print(self.key(feature_resnet18).shape)
            key_resnet_4 = self.transpose_for_scores(self.key(feature_resnet18))    # Bx12x64xK7xK7
            value_resnet_4 = self.transpose_for_scores(self.value(feature_resnet18))  # Bx12x64xV7xV7
            query_vit_4 = self.transpose_for_scores(self.query(vit_features_down_sampled)) # Bx12x64xQ7xQ7

            key_resnet_layer = key_resnet_4.reshape(key_resnet_4.shape[0], 12, 64, 7*7)  # Bx12x64x(K7xK7)
            value_resnet_layer = value_resnet_4.reshape(value_resnet_4.shape[0], 12, 64, 7*7)  # Bx12x64x(V7xV7)
            query_vit_layer = query_vit_4.reshape(query_vit_4.shape[0], 12, 64, 7*7)  # Bx12x64x(Q7xQ7)

            # Compute similarity matrix
            # Bx12x64x(Q7xQ7) x Bx12x64x(K7xK7) = Bx12x64(Q7xQ7)x(K7xK7)
            similarity_matrix = torch.matmul(query_vit_layer.transpose(-1, -2), key_resnet_layer)   

            attention_scores = similarity_matrix / math.sqrt(768 / 12)

            # Normalize the attention scores to probabilities.
            attention_probs = nn.functional.softmax(attention_scores, dim=-1)

            # This is actually dropping out entire tokens to attend to, which might
            # seem a bit unusual, but is taken from the original Transformer paper.
            attention_probs = self.dropout(attention_probs)

            # Apply attention weights to resnet_features
            # Bx12x64x(V7xV7) x Bx12x64x(K7xK7)x(Q7xQ7) = Bx12x64x(Q7xQ7)
            weighted_features = torch.matmul(value_resnet_layer, attention_probs.transpose(-1, -2))  # Bx12x64x(V7xV7) x Bx12x(K7xK7)x(Q7xQ7)

            # Combine the features
            # (Bx12x64x(Q7xQ7)->Bx768x(Q7xQ7)) + Bx768x(Q7xQ7) = Bx768x(Q7xQ7)
            combined_features = weighted_features.view_as(vit_features_down_sampled) + vit_features_down_sampled  # Bx768x7x7
            output, feature = self.attention_classifier(combined_features)

        else:

            # combined_features = torch.cat((feature_resnet18, vit_features_down_sampled), dim=1)  # Bx(512+768)x7x7
            # output, feature = self.concat_classifier(combined_features)

            
            if self.combination=="50-16" or self.combination=="50-32":
              combined_features = self.vit_projection_1(feature_resnet18)+vit_features_down_sampled
            else:
              combined_features = self.vit_projection_1(feature_resnet18)+vit_features_down_sampled

            # dropout
            combined_features = self.dropout(combined_features)
            output, feature = self.addition_classifier(combined_features)

            # print(final_embedding)
            # dropped_out_embeddings = self.dropout(final_embedding)

        return feature, output

    def load_model(self, path):
        self.load_state_dict(torch.load(path))

    def save_model(self, path):
        # torch.save(self.model.state_dict(), path)
        weights_path = os.path.join(path, "weights.pth")
        torch.save(self.state_dict(), weights_path)


class Classifier(nn.Module):
    def __init__(self, device, args, in_channels, num_classes, dropout_rate=0.5):
        super().__init__()
        self.args = args
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.norm = nn.BatchNorm2d(in_channels)
        self.dropout = nn.Dropout(dropout_rate)
        self.final_conv = nn.Conv2d(in_channels, num_classes, kernel_size=1).to(device)

    def forward(self, x):
        x = self.avgpool(x)
        feature = x.reshape(x.shape[0], -1)
        # print(feature.shape)
        x = self.norm(x)
        if str2bool(self.args.attention):
          x = self.dropout(x)
        # if self.args.loss_name == "Cross_Entropy":
        #   x = self.dropout(x)
        x = self.final_conv(x)  # This should output [batch_size, num_classes, 1, 1]
        x = x.view(x.size(0), -1)  # Flatten the tensor to [batch_size, num_classes]
        return x, feature

        

