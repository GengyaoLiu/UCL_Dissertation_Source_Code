import torch.nn.functional as F
import torch.nn as nn
import torch
import os
import torchvision
from transformers import ViTImageProcessor, ViTModel


class VIT_patch16(nn.Module):
    def __init__(self, device, freeze=True):
        super(VIT_patch16, self).__init__()

        # Load the pre-trained Vision Transformer model
        # self.processor = ViTImageProcessor.from_pretrained('google/vit-large-patch16-224-in21k')
        self.model = ViTModel.from_pretrained('google/vit-base-patch16-224')
        self.model.to(device)

        # Freeze the pre-trained layers
        for param in self.model.parameters():
            param.requires_grad = not freeze

        # Replace the last layer for fine-tuning
        num_classes = 4
        # print(self.model)
        self.model.pooler.dense = nn.Linear(self.model.pooler.dense.in_features, num_classes).to(device)

        # Explicitly set the parameters of the new layer to be trainable
        for param in self.model.pooler.dense.parameters():
            param.requires_grad = True

    def forward(self, device, x):
        # inputs = self.processor(x)
        outputs = self.model(pixel_values=x)
        # print(dir(outputs))
        embeddings = outputs.last_hidden_state[:, 0, :]
        logits = self.model.pooler.dense(embeddings)
        # print(embeddings.shape)
        return embeddings, logits

    def load_model(self, path):
        self.load_state_dict(torch.load(path))

    def save_model(self, path):
        # torch.save(self.model.state_dict(), path)
        weights_path = os.path.join(path, "weights.pth")
        torch.save(self.state_dict(), weights_path)



